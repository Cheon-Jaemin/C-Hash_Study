﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_KioskHospital
{
    public partial class ReserveChange : Base
    {
        private PatientInfo selectedPatient;
        string originDept;
        string originTime;

        public ReserveChange()
        {
            InitializeComponent();
            lbFirstRes.Text = "";
        }

        private void TimeSlot(string dept)
        {
            listBox2.Items.Clear();
            DateTime start = DateTime.Today.AddHours(9);
            DateTime end = DateTime.Today.AddHours(17);

            while (start < end)
            {
                string timeSlot = start.ToString("HH:mm");
                bool isTaken = Base.ReservedTimes.ContainsKey(dept) &&
                               Base.ReservedTimes[dept].Contains(timeSlot);

                if (isTaken)
                    listBox2.Items.Add($"{timeSlot} (예약됨)");
                else
                    listBox2.Items.Add(timeSlot);

                start = start.AddMinutes(30);
            }
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            string newDept = comboBox1.SelectedItem?.ToString();
            string selectTime = listBox2.SelectedItem?.ToString();

            if (newDept == null || selectTime == null || selectedPatient == null)
            {
                MessageBox.Show("변경할 정보를 정확히 선택해주세요.");
                return;
            }

            if (selectTime.Contains("예약됨"))
            {
                MessageBox.Show("이미 예약된 시간입니다. 다른 시간을 선택해주세요.");
                return;
            }
            
            string newTime = listBox2.SelectedItem?.ToString().Split(' ')[0];

            if (!string.IsNullOrEmpty(originDept) && Base.ReservedTimes.ContainsKey(originDept))
            {
                Base.ReservedTimes[originDept].Remove(originTime);
            }

            if (!Base.ReservedTimes.ContainsKey(newDept))
            {
                Base.ReservedTimes[newDept] = new List<string>();
            }
            Base.ReservedTimes[newDept].Add(newTime);

            selectedPatient.ReserveDept = newDept;
            selectedPatient.ReserveTime = newTime;

            originDept = newDept;
            originTime = newTime;

            lbFirstRes.Text = $"예약 정보 : {originDept} | {originTime}";

            MessageBox.Show("예약이 변경되었습니다.");
            TimeSlot(newDept);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (selectedPatient == null || string.IsNullOrEmpty(originDept) || string.IsNullOrEmpty(originTime))
            {
                MessageBox.Show("본인 정보를 먼저 확인해주세요.");
                return;
            }

            if (!string.IsNullOrEmpty(originDept) && Base.ReservedTimes.ContainsKey(originDept))
            {
                Base.ReservedTimes[originDept].Remove(originTime);

                selectedPatient.ReserveDept = null;
                selectedPatient.ReserveTime = null;

                originDept = null;
                originTime = null;
                lbFirstRes.Text = "현재 예약된 진료가 없습니다.";

                if(comboBox1.SelectedItem != null)
                {
                    TimeSlot(comboBox1.SelectedItem.ToString());
                }
                
                MessageBox.Show("정상적으로 예약이 취소되었습니다.");

                comboBox1.Enabled = false;
                listBox2.Enabled = false;
            }
            else
            {
                MessageBox.Show("예약된 정보가 없습니다.");
            }
        }

        private void btnResearch_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text.Trim();
            listBox1.Items.Clear();

            var match = Base.patients.Where(p => p.Name == name).ToList();
            if (match.Count == 0)
            {
                MessageBox.Show("등록된 환자 정보가 없습니다.");
                return;
            }

            foreach (var patient in match)
            {
                listBox1.Items.Add($"{patient.Name} | {patient.Age}세 | {patient.Birth.ToShortDateString()}");
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox1.SelectedIndex == -1)
            {
                return;
            }

            string select = listBox1.SelectedItem.ToString();
            string[] parts = select.Split('|');
            
            string name = parts[0].Trim();
            int age = int.Parse(parts[1].Replace("세", "").Trim());
            DateTime birth = DateTime.Parse(parts[2].Trim());

            selectedPatient = Base.patients.FirstOrDefault
                (p => p.Name == name && p.Age == age && p.Birth.Date == birth.Date);

            if (selectedPatient == null)
            {
                MessageBox.Show("선택한 환자 정보가 존재하지 않습니다.");
                return;
            }

            bool found = false;
            foreach (var dept in Base.ReservedTimes)
            {
                foreach (var time in dept.Value)
                {
                    if (selectedPatient.ReserveDept == dept.Key && selectedPatient.ReserveTime == time)
                    {
                        originDept = dept.Key;
                        originTime = time;
                        lbFirstRes.Text = $"예약 정보 : {originDept} | {originTime}";
                        found = true;
                        break;
                    }
                }
                if (found) break;
            }

            if (!found)
            {
                lbFirstRes.Text = "현재 예약된 진료가 없습니다.";
            }

            comboBox1.Enabled = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex == -1)
            {
                return;
            }

            string dept = comboBox1.SelectedItem.ToString();
            TimeSlot(dept);
            listBox2.Enabled = true;
        }
    }
}
