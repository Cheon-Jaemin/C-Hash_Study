﻿namespace C_KioskHospital
{
    partial class Base
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label2 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            btnHome = new Button();
            btnPrevi = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Font = new Font("Cafe24 Ohsquare", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(594, 660);
            label2.Name = "label2";
            label2.Size = new Size(16, 20);
            label2.TabIndex = 3;
            label2.Text = "-";
            label2.TextAlign = ContentAlignment.MiddleRight;
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.DodgerBlue;
            btnHome.BackgroundImage = Properties.Resources.free_icon_home_button_9073243;
            btnHome.BackgroundImageLayout = ImageLayout.Stretch;
            btnHome.Location = new Point(320, 630);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(50, 50);
            btnHome.TabIndex = 4;
            btnHome.UseVisualStyleBackColor = false;
            btnHome.Click += btnHome_Click;
            // 
            // btnPrevi
            // 
            btnPrevi.BackColor = Color.DodgerBlue;
            btnPrevi.BackgroundImage = Properties.Resources.free_icon_undo_8022662;
            btnPrevi.BackgroundImageLayout = ImageLayout.Stretch;
            btnPrevi.Location = new Point(107, 630);
            btnPrevi.Name = "btnPrevi";
            btnPrevi.Size = new Size(50, 50);
            btnPrevi.TabIndex = 4;
            btnPrevi.UseVisualStyleBackColor = false;
            btnPrevi.Click += btnPrevi_Click;
            // 
            // button1
            // 
            button1.Location = new Point(486, 657);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 5;
            button1.Text = "exit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Base
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(692, 696);
            Controls.Add(button1);
            Controls.Add(btnPrevi);
            Controls.Add(btnHome);
            Controls.Add(label2);
            Name = "Base";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Time";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private System.Windows.Forms.Timer timer1;
        private Button btnHome;
        private Button btnPrevi;
        private Button button1;
    }
}