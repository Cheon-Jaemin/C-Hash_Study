﻿namespace C_KioskHospital
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnMedical = new Button();
            btnReserve_Change = new Button();
            btnCert = new Button();
            btnHos = new Button();
            btnPay = new Button();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnMedical
            // 
            btnMedical.Font = new Font("Cafe24 Ohsquare", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnMedical.Location = new Point(105, 269);
            btnMedical.Name = "btnMedical";
            btnMedical.Size = new Size(135, 125);
            btnMedical.TabIndex = 0;
            btnMedical.Text = "진료 접수";
            btnMedical.UseVisualStyleBackColor = true;
            btnMedical.Click += btnMedical_Click;
            // 
            // btnReserve_Change
            // 
            btnReserve_Change.Font = new Font("Cafe24 Ohsquare", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnReserve_Change.Location = new Point(276, 269);
            btnReserve_Change.Name = "btnReserve_Change";
            btnReserve_Change.Size = new Size(135, 125);
            btnReserve_Change.TabIndex = 0;
            btnReserve_Change.Text = "진료\r\n변경/취소";
            btnReserve_Change.UseVisualStyleBackColor = true;
            btnReserve_Change.Click += btnReserve_Change_Click;
            // 
            // btnCert
            // 
            btnCert.Font = new Font("Cafe24 Ohsquare", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnCert.Location = new Point(190, 405);
            btnCert.Name = "btnCert";
            btnCert.Size = new Size(135, 125);
            btnCert.TabIndex = 0;
            btnCert.Text = "증명서 \r\n발급";
            btnCert.UseVisualStyleBackColor = true;
            btnCert.Click += btnCert_Click;
            // 
            // btnHos
            // 
            btnHos.Font = new Font("Cafe24 Ohsquare", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnHos.Location = new Point(361, 405);
            btnHos.Name = "btnHos";
            btnHos.Size = new Size(135, 125);
            btnHos.TabIndex = 0;
            btnHos.Text = "시설 안내";
            btnHos.UseVisualStyleBackColor = true;
            btnHos.Click += btnHos_Click;
            // 
            // btnPay
            // 
            btnPay.Font = new Font("Cafe24 Ohsquare", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnPay.Location = new Point(448, 269);
            btnPay.Name = "btnPay";
            btnPay.Size = new Size(135, 125);
            btnPay.TabIndex = 0;
            btnPay.Text = "수납";
            btnPay.UseVisualStyleBackColor = true;
            btnPay.Click += btnPay_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.v987_18a_Photoroom;
            pictureBox1.Location = new Point(297, 36);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 100);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("배스킨라빈스 B", 23.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(204, 192);
            label1.Name = "label1";
            label1.Size = new Size(294, 33);
            label1.TabIndex = 5;
            label1.Text = "몸과 마음을 건강하게!";
            // 
            // MainMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(692, 791);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(btnHos);
            Controls.Add(btnCert);
            Controls.Add(btnPay);
            Controls.Add(btnReserve_Change);
            Controls.Add(btnMedical);
            Name = "MainMenu";
            Text = "Moble";
            Controls.SetChildIndex(btnMedical, 0);
            Controls.SetChildIndex(btnReserve_Change, 0);
            Controls.SetChildIndex(btnPay, 0);
            Controls.SetChildIndex(btnCert, 0);
            Controls.SetChildIndex(btnHos, 0);
            Controls.SetChildIndex(pictureBox1, 0);
            Controls.SetChildIndex(label1, 0);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnMedical;
        private Button btnReserve_Change;
        private Button btnCert;
        private Button btnHos;
        private Button btnPay;
        private PictureBox pictureBox1;
        private Label label1;
    }
}