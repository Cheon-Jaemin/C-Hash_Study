﻿namespace C_KioskHospital
{
    partial class Pay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            listBox1 = new ListBox();
            label6 = new Label();
            textBox1 = new TextBox();
            btnResearch = new Button();
            pictureBox3 = new PictureBox();
            lbDept = new Label();
            lbMedCert = new Label();
            lbDocNote = new Label();
            ckbInsurance = new CheckBox();
            label10 = new Label();
            lbMedPrice = new Label();
            lbMedCertPrice = new Label();
            numericMedCert = new NumericUpDown();
            numericDocNote = new NumericUpDown();
            lbDocNotePrice = new Label();
            label14 = new Label();
            cbPayType = new ComboBox();
            listBox2 = new ListBox();
            btnPay = new Button();
            tbTotalPrice = new TextBox();
            label7 = new Label();
            lbInsuDiscount = new Label();
            panel1 = new Panel();
            panel2 = new Panel();
            panel3 = new Panel();
            panel4 = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            panel7 = new Panel();
            panel8 = new Panel();
            panel9 = new Panel();
            panel10 = new Panel();
            panel11 = new Panel();
            panel12 = new Panel();
            panel13 = new Panel();
            panel14 = new Panel();
            panel15 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericMedCert).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericDocNote).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            panel7.SuspendLayout();
            panel8.SuspendLayout();
            panel9.SuspendLayout();
            panel10.SuspendLayout();
            panel11.SuspendLayout();
            panel12.SuspendLayout();
            panel13.SuspendLayout();
            panel14.SuspendLayout();
            panel15.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Dock = DockStyle.Fill;
            label1.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(0, 0);
            label1.Name = "label1";
            label1.Size = new Size(79, 26);
            label1.TabIndex = 6;
            label1.Text = "진료비";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.Dock = DockStyle.Fill;
            label3.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(0, 0);
            label3.Name = "label3";
            label3.Size = new Size(79, 26);
            label3.TabIndex = 6;
            label3.Text = "진료확인서";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            label4.Dock = DockStyle.Fill;
            label4.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(0, 0);
            label4.Name = "label4";
            label4.Size = new Size(79, 26);
            label4.TabIndex = 6;
            label4.Text = "의사소견서";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            label5.Dock = DockStyle.Fill;
            label5.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(0, 0);
            label5.Name = "label5";
            label5.Size = new Size(79, 26);
            label5.TabIndex = 7;
            label5.Text = "보험적용여부";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(482, 257);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(196, 94);
            listBox1.TabIndex = 28;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(562, 177);
            label6.Name = "label6";
            label6.Size = new Size(35, 19);
            label6.TabIndex = 27;
            label6.Text = "이름";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(502, 199);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(157, 23);
            textBox1.TabIndex = 26;
            // 
            // btnResearch
            // 
            btnResearch.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnResearch.Location = new Point(547, 228);
            btnResearch.Name = "btnResearch";
            btnResearch.Size = new Size(67, 23);
            btnResearch.TabIndex = 25;
            btnResearch.Text = "검색";
            btnResearch.UseVisualStyleBackColor = true;
            btnResearch.Click += btnResearch_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.v987_18a_Photoroom;
            pictureBox3.Location = new Point(528, 12);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(100, 100);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 24;
            pictureBox3.TabStop = false;
            // 
            // lbDept
            // 
            lbDept.Dock = DockStyle.Fill;
            lbDept.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lbDept.Location = new Point(0, 0);
            lbDept.Name = "lbDept";
            lbDept.Size = new Size(128, 26);
            lbDept.TabIndex = 29;
            lbDept.Text = "진료과";
            lbDept.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbMedCert
            // 
            lbMedCert.Dock = DockStyle.Fill;
            lbMedCert.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lbMedCert.Location = new Point(0, 0);
            lbMedCert.Name = "lbMedCert";
            lbMedCert.Size = new Size(62, 26);
            lbMedCert.TabIndex = 30;
            lbMedCert.Text = "발급여부";
            lbMedCert.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbDocNote
            // 
            lbDocNote.Dock = DockStyle.Fill;
            lbDocNote.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lbDocNote.Location = new Point(0, 0);
            lbDocNote.Name = "lbDocNote";
            lbDocNote.Size = new Size(62, 26);
            lbDocNote.TabIndex = 30;
            lbDocNote.Text = "발급여부";
            lbDocNote.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // ckbInsurance
            // 
            ckbInsurance.CheckAlign = ContentAlignment.MiddleCenter;
            ckbInsurance.Dock = DockStyle.Fill;
            ckbInsurance.Location = new Point(0, 0);
            ckbInsurance.Name = "ckbInsurance";
            ckbInsurance.Size = new Size(62, 26);
            ckbInsurance.TabIndex = 31;
            ckbInsurance.UseVisualStyleBackColor = true;
            ckbInsurance.CheckedChanged += ckbInsurance_CheckedChanged;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("배스킨라빈스 B", 23.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(154, 52);
            label10.Name = "label10";
            label10.Size = new Size(133, 33);
            label10.TabIndex = 32;
            label10.Text = "무인 수납";
            // 
            // lbMedPrice
            // 
            lbMedPrice.Dock = DockStyle.Fill;
            lbMedPrice.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lbMedPrice.Location = new Point(0, 0);
            lbMedPrice.Name = "lbMedPrice";
            lbMedPrice.Size = new Size(93, 26);
            lbMedPrice.TabIndex = 33;
            lbMedPrice.Text = "금액";
            lbMedPrice.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbMedCertPrice
            // 
            lbMedCertPrice.Dock = DockStyle.Fill;
            lbMedCertPrice.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lbMedCertPrice.Location = new Point(0, 0);
            lbMedCertPrice.Name = "lbMedCertPrice";
            lbMedCertPrice.Size = new Size(93, 26);
            lbMedCertPrice.TabIndex = 33;
            lbMedCertPrice.Text = "금액";
            lbMedCertPrice.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // numericMedCert
            // 
            numericMedCert.Dock = DockStyle.Fill;
            numericMedCert.Enabled = false;
            numericMedCert.Location = new Point(0, 0);
            numericMedCert.Name = "numericMedCert";
            numericMedCert.Size = new Size(62, 23);
            numericMedCert.TabIndex = 34;
            numericMedCert.TextAlign = HorizontalAlignment.Center;
            numericMedCert.ValueChanged += numericMedCert_ValueChanged;
            // 
            // numericDocNote
            // 
            numericDocNote.Dock = DockStyle.Fill;
            numericDocNote.Enabled = false;
            numericDocNote.Location = new Point(0, 0);
            numericDocNote.Name = "numericDocNote";
            numericDocNote.Size = new Size(62, 23);
            numericDocNote.TabIndex = 34;
            numericDocNote.TextAlign = HorizontalAlignment.Center;
            numericDocNote.ValueChanged += numericDocNote_ValueChanged;
            // 
            // lbDocNotePrice
            // 
            lbDocNotePrice.Dock = DockStyle.Fill;
            lbDocNotePrice.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lbDocNotePrice.Location = new Point(0, 0);
            lbDocNotePrice.Name = "lbDocNotePrice";
            lbDocNotePrice.Size = new Size(93, 26);
            lbDocNotePrice.TabIndex = 33;
            lbDocNotePrice.Text = "금액";
            lbDocNotePrice.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(101, 387);
            label14.Name = "label14";
            label14.Size = new Size(46, 17);
            label14.TabIndex = 33;
            label14.Text = "총 금액";
            // 
            // cbPayType
            // 
            cbPayType.FormattingEnabled = true;
            cbPayType.Items.AddRange(new object[] { "신용카드", "체크카드" });
            cbPayType.Location = new Point(59, 445);
            cbPayType.Name = "cbPayType";
            cbPayType.Size = new Size(121, 23);
            cbPayType.TabIndex = 35;
            cbPayType.Text = "결제방식";
            cbPayType.SelectedIndexChanged += cbPayType_SelectedIndexChanged;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new Point(192, 445);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(150, 109);
            listBox2.TabIndex = 36;
            // 
            // btnPay
            // 
            btnPay.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnPay.Location = new Point(348, 445);
            btnPay.Name = "btnPay";
            btnPay.Size = new Size(75, 23);
            btnPay.TabIndex = 37;
            btnPay.Text = "결제";
            btnPay.UseVisualStyleBackColor = true;
            btnPay.Click += btnPay_Click;
            // 
            // tbTotalPrice
            // 
            tbTotalPrice.Location = new Point(160, 384);
            tbTotalPrice.Name = "tbTotalPrice";
            tbTotalPrice.ReadOnly = true;
            tbTotalPrice.Size = new Size(193, 23);
            tbTotalPrice.TabIndex = 38;
            // 
            // label7
            // 
            label7.Dock = DockStyle.Fill;
            label7.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(0, 0);
            label7.Name = "label7";
            label7.Size = new Size(62, 26);
            label7.TabIndex = 39;
            label7.Text = "10%";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbInsuDiscount
            // 
            lbInsuDiscount.Dock = DockStyle.Fill;
            lbInsuDiscount.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lbInsuDiscount.ForeColor = Color.Red;
            lbInsuDiscount.Location = new Point(0, 0);
            lbInsuDiscount.Name = "lbInsuDiscount";
            lbInsuDiscount.Size = new Size(93, 26);
            lbInsuDiscount.TabIndex = 33;
            lbInsuDiscount.Text = "금액";
            lbInsuDiscount.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            panel1.Controls.Add(label1);
            panel1.Location = new Point(62, 125);
            panel1.Name = "panel1";
            panel1.Size = new Size(79, 26);
            panel1.TabIndex = 40;
            // 
            // panel2
            // 
            panel2.Controls.Add(lbDept);
            panel2.Location = new Point(160, 125);
            panel2.Name = "panel2";
            panel2.Size = new Size(128, 26);
            panel2.TabIndex = 40;
            // 
            // panel3
            // 
            panel3.Controls.Add(lbMedPrice);
            panel3.Location = new Point(299, 125);
            panel3.Name = "panel3";
            panel3.Size = new Size(93, 26);
            panel3.TabIndex = 40;
            // 
            // panel4
            // 
            panel4.Controls.Add(label3);
            panel4.Location = new Point(62, 186);
            panel4.Name = "panel4";
            panel4.Size = new Size(79, 26);
            panel4.TabIndex = 40;
            // 
            // panel5
            // 
            panel5.Controls.Add(lbMedCert);
            panel5.Location = new Point(152, 186);
            panel5.Name = "panel5";
            panel5.Size = new Size(62, 26);
            panel5.TabIndex = 40;
            // 
            // panel6
            // 
            panel6.Controls.Add(numericMedCert);
            panel6.Location = new Point(226, 186);
            panel6.Name = "panel6";
            panel6.Size = new Size(62, 26);
            panel6.TabIndex = 40;
            // 
            // panel7
            // 
            panel7.Controls.Add(lbMedCertPrice);
            panel7.Location = new Point(299, 186);
            panel7.Name = "panel7";
            panel7.Size = new Size(93, 26);
            panel7.TabIndex = 40;
            // 
            // panel8
            // 
            panel8.Controls.Add(label4);
            panel8.Location = new Point(62, 251);
            panel8.Name = "panel8";
            panel8.Size = new Size(79, 26);
            panel8.TabIndex = 40;
            // 
            // panel9
            // 
            panel9.Controls.Add(lbDocNote);
            panel9.Location = new Point(152, 251);
            panel9.Name = "panel9";
            panel9.Size = new Size(62, 26);
            panel9.TabIndex = 40;
            // 
            // panel10
            // 
            panel10.Controls.Add(numericDocNote);
            panel10.Location = new Point(226, 251);
            panel10.Name = "panel10";
            panel10.Size = new Size(62, 26);
            panel10.TabIndex = 40;
            // 
            // panel11
            // 
            panel11.Controls.Add(lbDocNotePrice);
            panel11.Location = new Point(299, 251);
            panel11.Name = "panel11";
            panel11.Size = new Size(93, 26);
            panel11.TabIndex = 40;
            // 
            // panel12
            // 
            panel12.Controls.Add(label5);
            panel12.Location = new Point(62, 319);
            panel12.Name = "panel12";
            panel12.Size = new Size(79, 26);
            panel12.TabIndex = 40;
            // 
            // panel13
            // 
            panel13.Controls.Add(ckbInsurance);
            panel13.Location = new Point(152, 319);
            panel13.Name = "panel13";
            panel13.Size = new Size(62, 26);
            panel13.TabIndex = 40;
            // 
            // panel14
            // 
            panel14.Controls.Add(label7);
            panel14.Location = new Point(226, 319);
            panel14.Name = "panel14";
            panel14.Size = new Size(62, 26);
            panel14.TabIndex = 40;
            // 
            // panel15
            // 
            panel15.Controls.Add(lbInsuDiscount);
            panel15.Location = new Point(299, 319);
            panel15.Name = "panel15";
            panel15.Size = new Size(93, 26);
            panel15.TabIndex = 40;
            // 
            // Pay
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(692, 696);
            Controls.Add(panel15);
            Controls.Add(panel14);
            Controls.Add(panel13);
            Controls.Add(panel12);
            Controls.Add(panel11);
            Controls.Add(panel10);
            Controls.Add(panel9);
            Controls.Add(panel8);
            Controls.Add(panel7);
            Controls.Add(panel6);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(tbTotalPrice);
            Controls.Add(btnPay);
            Controls.Add(listBox2);
            Controls.Add(cbPayType);
            Controls.Add(label14);
            Controls.Add(label10);
            Controls.Add(listBox1);
            Controls.Add(label6);
            Controls.Add(textBox1);
            Controls.Add(btnResearch);
            Controls.Add(pictureBox3);
            Name = "Pay";
            Text = "Moble";
            Controls.SetChildIndex(pictureBox3, 0);
            Controls.SetChildIndex(btnResearch, 0);
            Controls.SetChildIndex(textBox1, 0);
            Controls.SetChildIndex(label6, 0);
            Controls.SetChildIndex(listBox1, 0);
            Controls.SetChildIndex(label10, 0);
            Controls.SetChildIndex(label14, 0);
            Controls.SetChildIndex(cbPayType, 0);
            Controls.SetChildIndex(listBox2, 0);
            Controls.SetChildIndex(btnPay, 0);
            Controls.SetChildIndex(tbTotalPrice, 0);
            Controls.SetChildIndex(panel1, 0);
            Controls.SetChildIndex(panel2, 0);
            Controls.SetChildIndex(panel3, 0);
            Controls.SetChildIndex(panel4, 0);
            Controls.SetChildIndex(panel5, 0);
            Controls.SetChildIndex(panel6, 0);
            Controls.SetChildIndex(panel7, 0);
            Controls.SetChildIndex(panel8, 0);
            Controls.SetChildIndex(panel9, 0);
            Controls.SetChildIndex(panel10, 0);
            Controls.SetChildIndex(panel11, 0);
            Controls.SetChildIndex(panel12, 0);
            Controls.SetChildIndex(panel13, 0);
            Controls.SetChildIndex(panel14, 0);
            Controls.SetChildIndex(panel15, 0);
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericMedCert).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericDocNote).EndInit();
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel8.ResumeLayout(false);
            panel9.ResumeLayout(false);
            panel10.ResumeLayout(false);
            panel11.ResumeLayout(false);
            panel12.ResumeLayout(false);
            panel13.ResumeLayout(false);
            panel14.ResumeLayout(false);
            panel15.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private ListBox listBox1;
        private Label label6;
        private TextBox textBox1;
        private Button btnResearch;
        private PictureBox pictureBox3;
        private Label lbDept;
        private Label lbMedCert;
        private Label lbDocNote;
        private CheckBox ckbInsurance;
        private Label label10;
        private Label lbMedPrice;
        private Label lbMedCertPrice;
        private NumericUpDown numericMedCert;
        private NumericUpDown numericDocNote;
        private Label lbDocNotePrice;
        private Label label14;
        private ComboBox cbPayType;
        private ListBox listBox2;
        private Button btnPay;
        private TextBox tbTotalPrice;
        private Label label7;
        private Label lbInsuDiscount;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Panel panel6;
        private Panel panel7;
        private Panel panel8;
        private Panel panel9;
        private Panel panel10;
        private Panel panel11;
        private Panel panel12;
        private Panel panel13;
        private Panel panel14;
        private Panel panel15;
    }
}