﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_KioskHospital
{
    public partial class ReMed : Base
    {
        private PatientInfo selectedPatient;

        public ReMed()
        {
            InitializeComponent();
        }

        private void TimeSlot(string dept)
        {
            listBox2.Items.Clear();
            DateTime start = DateTime.Today.AddHours(9);
            DateTime end = DateTime.Today.AddHours(17);

            while (start < end)
            {
                string timeSlot = start.ToString("HH:mm");
                bool isTaken = Base.ReservedTimes.ContainsKey(dept) &&
                               Base.ReservedTimes[dept].Contains(timeSlot);

                if (isTaken)
                    listBox2.Items.Add($"{timeSlot} (예약됨)");
                else
                    listBox2.Items.Add(timeSlot);

                start = start.AddMinutes(30);
            }
        }

        private void btnResearch_Click(object sender, EventArgs e)
        {
            string Name = textBox1.Text.Trim();

            if (Name == "" || Name == null)
            {
                MessageBox.Show("이름을 입력해주세요.");
                return;
            }

            var match = Base.patients
                .Where(p => p.Name == Name)
                .ToList();

            listBox1.Items.Clear();

            if (match.Count == 0)
            {
                MessageBox.Show("등록된 환자 정보가 없습니다.");
                return;
            }

            foreach (var patient in match)
            {
                listBox1.Items.Add($"{patient.Name} | {patient.Age}세 | {patient.Birth.ToShortDateString()}");
            }
        }

        
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox1.SelectedIndex == -1)
            {
                return;
            }

            int index = listBox1.SelectedIndex;
            if (index >= 0)
            {
                string name = textBox1.Text.Trim();
                var match = Base.patients.Where(p => p.Name == name).ToList();
                selectedPatient = match[index];

                comboBox1.Enabled = true;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex == -1)
            {
                return;
            }

            string dept = comboBox1.SelectedItem.ToString();
            TimeSlot(dept);
            listBox2.Enabled = true;
        }

        private void btnSumit_Click(object sender, EventArgs e)
        {
            if(selectedPatient == null)
            {
                MessageBox.Show("본인 정보를 먼저 확인해주세요.");
                return;
            }

            string dept = comboBox1.SelectedItem?.ToString();
            string selectedTime = listBox2.SelectedItem?.ToString();

            if (dept == null || selectedTime == null)
            {
                MessageBox.Show("진료과와 시간을 모두 선택해주세요.");
                return;
            }

            if(selectedTime.Contains("예약됨"))
            {
                MessageBox.Show("이미 예약된 시간입니다. 다른 시간을 선택해주세요.");
                return;
            }

            string reserveTime = selectedTime.Split(' ')[0];
            if(!Base.ReservedTimes.ContainsKey(dept))
            {
                Base.ReservedTimes[dept] = new List<string>();
            }

            Base.ReservedTimes[dept].Add(reserveTime);
            selectedPatient.ReserveDept = dept;
            selectedPatient.ReserveTime = reserveTime;

            MessageBox.Show($"{selectedPatient.Name}님, {dept} {reserveTime}에 진료가 접수되었습니다.");

            listBox2.Items.Clear();
            comboBox1.Enabled = false;
            listBox2.Enabled = false;
        }
    }
}
