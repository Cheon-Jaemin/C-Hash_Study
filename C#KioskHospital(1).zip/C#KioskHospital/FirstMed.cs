﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_KioskHospital
{
    public partial class FirstMed : Base
    {
        public FirstMed()
        {
            InitializeComponent();
        }


        private void TimeSlot(string dept)
        {
            listBox1.Items.Clear();

            DateTime start = DateTime.Today.AddHours(9);
            DateTime end = DateTime.Today.AddHours(17);

            while (start < end)
            {
                string timeSlot = start.ToString("HH:mm");

                bool isTaken = IsTimeSlotTaken(dept, timeSlot);
                if (isTaken)
                {
                    listBox1.Items.Add($"{timeSlot} (예약됨)");
                }
                else
                {
                    listBox1.Items.Add(timeSlot);
                }

                start = start.AddMinutes(30);
            }
        }

        private bool IsTimeSlotTaken(string dept, string time)
        {
            return Base.ReservedTimes.ContainsKey(dept) && Base.ReservedTimes[dept].Contains(time);
        }

        private void btnRegist_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            int age = (int)numericUpDown1.Value;
            DateTime birth = dateTimePicker1.Value;

            string dept = comboBox1.SelectedItem?.ToString();
            string selectedTime = listBox1.SelectedItem?.ToString();

            if(name == null || name == "" || dept == null || selectedTime == null)
            {
                MessageBox.Show("모든 정보를 입력해주세요.");
                return;
            }

            if (selectedTime.Contains("예약됨"))
            {
                MessageBox.Show("이미 예약된 시간입니다. 다른 시간을 선택해주세요.");
                return;
            }

            if(age <= 0)
            {
                MessageBox.Show("올바른 나이를 입력해주세요.");
                return;
            }

            if(birth > DateTime.Today)
            {
                MessageBox.Show("생년월일이 올바르지 않습니다.");
                return;
            }

            string reserveTime = selectedTime.Split(' ')[0];
            if(!Base.ReservedTimes.ContainsKey(dept))
            {
                Base.ReservedTimes[dept] = new List<string>();
            }
            Base.ReservedTimes[dept].Add(reserveTime);

            MessageBox.Show($"{name}님, {dept} {reserveTime}에 진료가 접수되었습니다.");

            bool alreadyExists = patients.Any(p => 
            p.Name == name &&
            p.Age == age&&
            p.Birth.Date == birth.Date
            );

            if(!alreadyExists)
            {
                patients.Add(new PatientInfo
                {
                    Name = name,
                    Age = age,
                    Birth = birth.Date,
                    ReserveDept = dept,
                    ReserveTime = reserveTime
                });
            }
            else
            {
                MessageBox.Show("이미 등록된 환자입니다.");
                return;
            }

            textBox1.Clear();
            numericUpDown1.Value = 0;
            
            TimeSlot(dept);


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex == -1)
            {
                return;
            }

            string selectedCombo = comboBox1.SelectedItem.ToString();
            TimeSlot(selectedCombo);
        }
    }
}
  
