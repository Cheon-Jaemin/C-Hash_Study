﻿namespace C_KioskHospital
{
    partial class Certificate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            pictureBox1 = new PictureBox();
            btnDocNote = new Button();
            btnMedCert = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("배스킨라빈스 B", 23.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(272, 192);
            label1.Name = "label1";
            label1.Size = new Size(154, 33);
            label1.TabIndex = 9;
            label1.Text = "증명서발급";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.v987_18a_Photoroom;
            pictureBox1.Location = new Point(297, 36);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 100);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // btnDocNote
            // 
            btnDocNote.Font = new Font("Cafe24 Ohsquare", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnDocNote.Location = new Point(362, 303);
            btnDocNote.Name = "btnDocNote";
            btnDocNote.Size = new Size(135, 125);
            btnDocNote.TabIndex = 11;
            btnDocNote.Text = "소견서";
            btnDocNote.UseVisualStyleBackColor = true;
            btnDocNote.Click += btnDocNote_Click;
            // 
            // btnMedCert
            // 
            btnMedCert.Font = new Font("Cafe24 Ohsquare", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnMedCert.Location = new Point(191, 303);
            btnMedCert.Name = "btnMedCert";
            btnMedCert.Size = new Size(135, 125);
            btnMedCert.TabIndex = 12;
            btnMedCert.Text = "진료확인서";
            btnMedCert.UseVisualStyleBackColor = true;
            btnMedCert.Click += btnMedCert_Click;
            // 
            // Certificate
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(692, 696);
            Controls.Add(btnDocNote);
            Controls.Add(btnMedCert);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Name = "Certificate";
            Text = "moble";
            Controls.SetChildIndex(pictureBox1, 0);
            Controls.SetChildIndex(label1, 0);
            Controls.SetChildIndex(btnMedCert, 0);
            Controls.SetChildIndex(btnDocNote, 0);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private Button btnDocNote;
        private Button btnMedCert;
    }
}