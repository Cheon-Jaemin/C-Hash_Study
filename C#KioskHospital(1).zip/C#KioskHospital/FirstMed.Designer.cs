﻿namespace C_KioskHospital
{
    partial class FirstMed
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            numericUpDown1 = new NumericUpDown();
            dateTimePicker1 = new DateTimePicker();
            comboBox1 = new ComboBox();
            label6 = new Label();
            listBox1 = new ListBox();
            btnRegist = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(291, 258);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(157, 23);
            textBox1.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("배스킨라빈스 B", 23.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(271, 192);
            label1.Name = "label1";
            label1.Size = new Size(167, 33);
            label1.TabIndex = 9;
            label1.Text = "환영합니다.";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.v987_18a_Photoroom;
            pictureBox1.Location = new Point(297, 36);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 100);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(212, 260);
            label3.Name = "label3";
            label3.Size = new Size(35, 19);
            label3.TabIndex = 10;
            label3.Text = "이름";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(212, 304);
            label4.Name = "label4";
            label4.Size = new Size(35, 19);
            label4.TabIndex = 10;
            label4.Text = "나이";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(199, 350);
            label5.Name = "label5";
            label5.Size = new Size(61, 19);
            label5.TabIndex = 10;
            label5.Text = "생년월일";
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(293, 303);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(155, 23);
            numericUpDown1.TabIndex = 11;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(273, 348);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 23);
            dateTimePicker1.TabIndex = 12;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "내과", "이비인후과", "소아과" });
            comboBox1.Location = new Point(171, 423);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 13;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(107, 424);
            label6.Name = "label6";
            label6.Size = new Size(52, 19);
            label6.TabIndex = 10;
            label6.Text = "진료 과";
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(320, 423);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(148, 184);
            listBox1.TabIndex = 14;
            // 
            // btnRegist
            // 
            btnRegist.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            btnRegist.Location = new Point(504, 423);
            btnRegist.Name = "btnRegist";
            btnRegist.Size = new Size(74, 45);
            btnRegist.TabIndex = 15;
            btnRegist.Text = "접수";
            btnRegist.UseVisualStyleBackColor = true;
            btnRegist.Click += btnRegist_Click;
            // 
            // FirstMed
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(692, 791);
            Controls.Add(btnRegist);
            Controls.Add(listBox1);
            Controls.Add(comboBox1);
            Controls.Add(dateTimePicker1);
            Controls.Add(numericUpDown1);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(textBox1);
            Name = "FirstMed";
            Text = "Moble";
            Controls.SetChildIndex(textBox1, 0);
            Controls.SetChildIndex(pictureBox1, 0);
            Controls.SetChildIndex(label1, 0);
            Controls.SetChildIndex(label3, 0);
            Controls.SetChildIndex(label4, 0);
            Controls.SetChildIndex(label5, 0);
            Controls.SetChildIndex(label6, 0);
            Controls.SetChildIndex(numericUpDown1, 0);
            Controls.SetChildIndex(dateTimePicker1, 0);
            Controls.SetChildIndex(comboBox1, 0);
            Controls.SetChildIndex(listBox1, 0);
            Controls.SetChildIndex(btnRegist, 0);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label3;
        private Label label4;
        private Label label5;
        private NumericUpDown numericUpDown1;
        private DateTimePicker dateTimePicker1;
        private ComboBox comboBox1;
        private Label label6;
        private ListBox listBox1;
        private Button btnRegist;
    }
}