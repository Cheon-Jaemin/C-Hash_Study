﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_KioskHospital
{
    public partial class MainMenu : Base
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void btnMedical_Click(object sender, EventArgs e)
        {
            Navigation.FormStack.Push(this);
            Medical medical = new Medical();
            medical.Show();
            this.Hide();
        }

        private void btnHos_Click(object sender, EventArgs e)
        {
            Navigation.FormStack.Push(this);
            Building building = new Building();
            building.Show();
            this.Hide();
        }

        private void btnReserve_Change_Click(object sender, EventArgs e)
        {
            Navigation.FormStack.Push(this);
            ReserveChange reserveChange = new ReserveChange();
            reserveChange.Show();
            this.Hide();
        }

        private void btnCert_Click(object sender, EventArgs e)
        {
            Navigation.FormStack.Push(this);
            Certificate certificate = new Certificate();
            certificate.Show();
            this.Hide();
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            Navigation.FormStack.Push(this);
            Pay payment = new Pay();
            payment.Show();
            this.Hide();
        }
    }
}
