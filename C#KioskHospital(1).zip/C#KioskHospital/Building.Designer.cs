﻿namespace C_KioskHospital
{
    partial class Building
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources._1232;
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(668, 329);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Cafe24 Ohsquare", 15.7499981F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(192, 366);
            label1.Name = "label1";
            label1.Size = new Size(37, 27);
            label1.TabIndex = 6;
            label1.Text = "3F";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Cafe24 Ohsquare", 15.7499981F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(192, 436);
            label3.Name = "label3";
            label3.Size = new Size(37, 27);
            label3.TabIndex = 6;
            label3.Text = "2F";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Cafe24 Ohsquare", 15.7499981F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(192, 506);
            label4.Name = "label4";
            label4.Size = new Size(33, 27);
            label4.TabIndex = 6;
            label4.Text = "1F";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Cafe24 Ohsquare", 15.7499981F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(237, 366);
            label5.Name = "label5";
            label5.Size = new Size(22, 27);
            label5.TabIndex = 6;
            label5.Text = "-";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Cafe24 Ohsquare", 15.7499981F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(237, 436);
            label6.Name = "label6";
            label6.Size = new Size(22, 27);
            label6.TabIndex = 6;
            label6.Text = "-";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Cafe24 Ohsquare", 15.7499981F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(237, 506);
            label7.Name = "label7";
            label7.Size = new Size(22, 27);
            label7.TabIndex = 6;
            label7.Text = "-";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Cafe24 Ohsquare", 15.7499981F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(265, 366);
            label8.Name = "label8";
            label8.Size = new Size(216, 27);
            label8.TabIndex = 6;
            label8.Text = "내과 | 301 ~ 309 병동";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Cafe24 Ohsquare", 15.7499981F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(265, 436);
            label9.Name = "label9";
            label9.Size = new Size(272, 27);
            label9.TabIndex = 6;
            label9.Text = "이비인후과 | 201 ~ 209 병동";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Cafe24 Ohsquare", 15.7499981F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(265, 506);
            label10.Name = "label10";
            label10.Size = new Size(245, 27);
            label10.TabIndex = 6;
            label10.Text = "소아과 | 원무팀 | 모블약국 ";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Cafe24 Ohsquare", 15.7499981F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(192, 576);
            label11.Name = "label11";
            label11.Size = new Size(35, 27);
            label11.TabIndex = 6;
            label11.Text = "B1";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Cafe24 Ohsquare", 15.7499981F, FontStyle.Regular, GraphicsUnit.Point);
            label12.Location = new Point(237, 576);
            label12.Name = "label12";
            label12.Size = new Size(22, 27);
            label12.TabIndex = 6;
            label12.Text = "-";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Cafe24 Ohsquare", 15.7499981F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(265, 576);
            label13.Name = "label13";
            label13.Size = new Size(184, 27);
            label13.TabIndex = 6;
            label13.Text = "지하주차장 | 시설팀";
            // 
            // Building
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(692, 696);
            Controls.Add(label13);
            Controls.Add(label10);
            Controls.Add(label12);
            Controls.Add(label9);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label11);
            Controls.Add(label8);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Name = "Building";
            Text = "Moble";
            Controls.SetChildIndex(pictureBox1, 0);
            Controls.SetChildIndex(label1, 0);
            Controls.SetChildIndex(label3, 0);
            Controls.SetChildIndex(label5, 0);
            Controls.SetChildIndex(label4, 0);
            Controls.SetChildIndex(label8, 0);
            Controls.SetChildIndex(label11, 0);
            Controls.SetChildIndex(label6, 0);
            Controls.SetChildIndex(label7, 0);
            Controls.SetChildIndex(label9, 0);
            Controls.SetChildIndex(label12, 0);
            Controls.SetChildIndex(label10, 0);
            Controls.SetChildIndex(label13, 0);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
    }
}