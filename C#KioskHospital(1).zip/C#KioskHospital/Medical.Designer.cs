﻿namespace C_KioskHospital
{
    partial class Medical
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            pictureBox1 = new PictureBox();
            btnReMed = new Button();
            btnFirstMed = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("배스킨라빈스 B", 23.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(279, 192);
            label1.Name = "label1";
            label1.Size = new Size(134, 33);
            label1.TabIndex = 7;
            label1.Text = "진료 접수";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.v987_18a_Photoroom;
            pictureBox1.Location = new Point(297, 36);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 100);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // btnReMed
            // 
            btnReMed.Font = new Font("Cafe24 Ohsquare", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnReMed.Location = new Point(361, 303);
            btnReMed.Name = "btnReMed";
            btnReMed.Size = new Size(135, 125);
            btnReMed.TabIndex = 9;
            btnReMed.Text = "재진";
            btnReMed.UseVisualStyleBackColor = true;
            btnReMed.Click += btnReMed_Click;
            // 
            // btnFirstMed
            // 
            btnFirstMed.Font = new Font("Cafe24 Ohsquare", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnFirstMed.Location = new Point(190, 303);
            btnFirstMed.Name = "btnFirstMed";
            btnFirstMed.Size = new Size(135, 125);
            btnFirstMed.TabIndex = 10;
            btnFirstMed.Text = "초진";
            btnFirstMed.UseVisualStyleBackColor = true;
            btnFirstMed.Click += btnFirstMed_Click;
            // 
            // Medical
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(692, 696);
            Controls.Add(btnReMed);
            Controls.Add(btnFirstMed);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Name = "Medical";
            Text = "Moble";
            Controls.SetChildIndex(pictureBox1, 0);
            Controls.SetChildIndex(label1, 0);
            Controls.SetChildIndex(btnFirstMed, 0);
            Controls.SetChildIndex(btnReMed, 0);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private Button btnReMed;
        private Button btnFirstMed;
    }
}