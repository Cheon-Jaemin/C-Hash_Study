﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_KioskHospital
{
    public partial class Certificate : Base
    {
        public Certificate()
        {
            InitializeComponent();
        }

        private void btnMedCert_Click(object sender, EventArgs e)
        {
            Navigation.FormStack.Push(this);
            MedCertificate medCertificate = new MedCertificate();
            medCertificate.Show();
            this.Hide();
        }

        private void btnDocNote_Click(object sender, EventArgs e)
        {
            Navigation.FormStack.Push(this);
            DoctorNote doctorNote = new DoctorNote();
            doctorNote.Show();
            this.Hide();
        }
    }
}
