﻿namespace C_KioskHospital
{
    partial class ReMed
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            pictureBox1 = new PictureBox();
            btnResearch = new Button();
            label3 = new Label();
            textBox1 = new TextBox();
            listBox1 = new ListBox();
            btnSumit = new Button();
            listBox2 = new ListBox();
            comboBox1 = new ComboBox();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("배스킨라빈스 B", 23.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(266, 192);
            label1.Name = "label1";
            label1.Size = new Size(164, 33);
            label1.TabIndex = 11;
            label1.Text = "어서오세요.";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.v987_18a_Photoroom;
            pictureBox1.Location = new Point(297, 36);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 100);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // btnResearch
            // 
            btnResearch.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnResearch.Location = new Point(433, 261);
            btnResearch.Name = "btnResearch";
            btnResearch.Size = new Size(67, 23);
            btnResearch.TabIndex = 16;
            btnResearch.Text = "검색";
            btnResearch.UseVisualStyleBackColor = true;
            btnResearch.Click += btnResearch_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(202, 263);
            label3.Name = "label3";
            label3.Size = new Size(35, 19);
            label3.TabIndex = 18;
            label3.Text = "이름";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(261, 261);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(157, 23);
            textBox1.TabIndex = 17;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(202, 290);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(298, 94);
            listBox1.TabIndex = 19;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // btnSumit
            // 
            btnSumit.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            btnSumit.Location = new Point(508, 425);
            btnSumit.Name = "btnSumit";
            btnSumit.Size = new Size(74, 45);
            btnSumit.TabIndex = 23;
            btnSumit.Text = "접수";
            btnSumit.UseVisualStyleBackColor = true;
            btnSumit.Click += btnSumit_Click;
            // 
            // listBox2
            // 
            listBox2.Enabled = false;
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new Point(324, 425);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(148, 184);
            listBox2.TabIndex = 22;
            // 
            // comboBox1
            // 
            comboBox1.Enabled = false;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "내과", "이비인후과", "소아과" });
            comboBox1.Location = new Point(175, 425);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 21;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(111, 426);
            label6.Name = "label6";
            label6.Size = new Size(52, 19);
            label6.TabIndex = 20;
            label6.Text = "진료 과";
            // 
            // ReMed
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(692, 791);
            Controls.Add(btnSumit);
            Controls.Add(listBox2);
            Controls.Add(comboBox1);
            Controls.Add(label6);
            Controls.Add(listBox1);
            Controls.Add(label3);
            Controls.Add(textBox1);
            Controls.Add(btnResearch);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Name = "ReMed";
            Text = "Moble";
            Controls.SetChildIndex(pictureBox1, 0);
            Controls.SetChildIndex(label1, 0);
            Controls.SetChildIndex(btnResearch, 0);
            Controls.SetChildIndex(textBox1, 0);
            Controls.SetChildIndex(label3, 0);
            Controls.SetChildIndex(listBox1, 0);
            Controls.SetChildIndex(label6, 0);
            Controls.SetChildIndex(comboBox1, 0);
            Controls.SetChildIndex(listBox2, 0);
            Controls.SetChildIndex(btnSumit, 0);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private Button btnResearch;
        private Label label3;
        private TextBox textBox1;
        private ListBox listBox1;
        private Button btnSumit;
        private ListBox listBox2;
        private ComboBox comboBox1;
        private Label label6;
    }
}