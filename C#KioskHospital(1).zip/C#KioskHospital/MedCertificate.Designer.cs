﻿namespace C_KioskHospital
{
    partial class MedCertificate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            lbName = new Label();
            panel2 = new Panel();
            lbAge = new Label();
            panel3 = new Panel();
            lbBirth = new Label();
            panel5 = new Panel();
            label6 = new Label();
            panel4 = new Panel();
            lbDept = new Label();
            pictureBox3 = new PictureBox();
            listBox1 = new ListBox();
            label3 = new Label();
            textBox1 = new TextBox();
            btnResearch = new Button();
            btnIssuance = new Button();
            label1 = new Label();
            lbFee = new Label();
            panel6 = new Panel();
            lbDate = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel6.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.jin1;
            pictureBox1.Location = new Point(32, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(429, 612);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(lbName);
            panel1.Location = new Point(115, 172);
            panel1.Name = "panel1";
            panel1.Size = new Size(65, 23);
            panel1.TabIndex = 7;
            // 
            // lbName
            // 
            lbName.Font = new Font("맑은 고딕", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            lbName.Location = new Point(0, 0);
            lbName.Name = "lbName";
            lbName.Size = new Size(65, 23);
            lbName.TabIndex = 0;
            lbName.Text = "label1";
            lbName.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            panel2.Controls.Add(lbAge);
            panel2.Location = new Point(247, 172);
            panel2.Name = "panel2";
            panel2.Size = new Size(42, 23);
            panel2.TabIndex = 8;
            // 
            // lbAge
            // 
            lbAge.Font = new Font("맑은 고딕", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            lbAge.Location = new Point(0, 0);
            lbAge.Name = "lbAge";
            lbAge.Size = new Size(42, 23);
            lbAge.TabIndex = 0;
            lbAge.Text = "label4";
            lbAge.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            panel3.Controls.Add(lbBirth);
            panel3.Controls.Add(panel5);
            panel3.Location = new Point(341, 172);
            panel3.Name = "panel3";
            panel3.Size = new Size(104, 23);
            panel3.TabIndex = 9;
            // 
            // lbBirth
            // 
            lbBirth.Font = new Font("맑은 고딕", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            lbBirth.Location = new Point(1, 0);
            lbBirth.Name = "lbBirth";
            lbBirth.Size = new Size(102, 23);
            lbBirth.TabIndex = 0;
            lbBirth.Text = "label3";
            lbBirth.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            panel5.Controls.Add(label6);
            panel5.Location = new Point(3, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(102, 23);
            panel5.TabIndex = 9;
            // 
            // label6
            // 
            label6.Location = new Point(3, 0);
            label6.Name = "label6";
            label6.Size = new Size(102, 23);
            label6.TabIndex = 0;
            label6.Text = "label3";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            panel4.Controls.Add(lbDept);
            panel4.Location = new Point(115, 198);
            panel4.Name = "panel4";
            panel4.Size = new Size(330, 25);
            panel4.TabIndex = 10;
            // 
            // lbDept
            // 
            lbDept.Font = new Font("맑은 고딕", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            lbDept.Location = new Point(0, -2);
            lbDept.Name = "lbDept";
            lbDept.Size = new Size(330, 26);
            lbDept.TabIndex = 0;
            lbDept.Text = "label5";
            lbDept.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.v987_18a_Photoroom;
            pictureBox3.Location = new Point(528, 12);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(100, 100);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 11;
            pictureBox3.TabStop = false;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(482, 257);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(196, 94);
            listBox1.TabIndex = 23;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(562, 177);
            label3.Name = "label3";
            label3.Size = new Size(35, 19);
            label3.TabIndex = 22;
            label3.Text = "이름";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(502, 199);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(157, 23);
            textBox1.TabIndex = 21;
            // 
            // btnResearch
            // 
            btnResearch.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnResearch.Location = new Point(547, 228);
            btnResearch.Name = "btnResearch";
            btnResearch.Size = new Size(67, 23);
            btnResearch.TabIndex = 20;
            btnResearch.Text = "검색";
            btnResearch.UseVisualStyleBackColor = true;
            btnResearch.Click += btnResearch_Click;
            // 
            // btnIssuance
            // 
            btnIssuance.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            btnIssuance.Location = new Point(547, 430);
            btnIssuance.Name = "btnIssuance";
            btnIssuance.Size = new Size(67, 60);
            btnIssuance.TabIndex = 20;
            btnIssuance.Text = "발급";
            btnIssuance.UseVisualStyleBackColor = true;
            btnIssuance.Click += btnIssuance_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(529, 381);
            label1.Name = "label1";
            label1.Size = new Size(48, 19);
            label1.TabIndex = 22;
            label1.Text = "수수료";
            // 
            // lbFee
            // 
            lbFee.AutoSize = true;
            lbFee.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            lbFee.Location = new Point(583, 381);
            lbFee.Name = "lbFee";
            lbFee.Size = new Size(49, 19);
            lbFee.TabIndex = 22;
            lbFee.Text = "3000";
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(241, 251, 251);
            panel6.Controls.Add(lbDate);
            panel6.Location = new Point(130, 262);
            panel6.Name = "panel6";
            panel6.Size = new Size(159, 27);
            panel6.TabIndex = 24;
            // 
            // lbDate
            // 
            lbDate.Dock = DockStyle.Fill;
            lbDate.Font = new Font("맑은 고딕", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            lbDate.Location = new Point(0, 0);
            lbDate.Name = "lbDate";
            lbDate.Size = new Size(159, 27);
            lbDate.TabIndex = 0;
            lbDate.Text = "label4";
            lbDate.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // MedCertificate
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(692, 696);
            Controls.Add(panel6);
            Controls.Add(listBox1);
            Controls.Add(lbFee);
            Controls.Add(label1);
            Controls.Add(label3);
            Controls.Add(textBox1);
            Controls.Add(btnIssuance);
            Controls.Add(btnResearch);
            Controls.Add(pictureBox3);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(pictureBox1);
            Name = "MedCertificate";
            Text = "Moble";
            Controls.SetChildIndex(pictureBox1, 0);
            Controls.SetChildIndex(panel1, 0);
            Controls.SetChildIndex(panel2, 0);
            Controls.SetChildIndex(panel3, 0);
            Controls.SetChildIndex(panel4, 0);
            Controls.SetChildIndex(pictureBox3, 0);
            Controls.SetChildIndex(btnResearch, 0);
            Controls.SetChildIndex(btnIssuance, 0);
            Controls.SetChildIndex(textBox1, 0);
            Controls.SetChildIndex(label3, 0);
            Controls.SetChildIndex(label1, 0);
            Controls.SetChildIndex(lbFee, 0);
            Controls.SetChildIndex(listBox1, 0);
            Controls.SetChildIndex(panel6, 0);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel6.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Panel panel1;
        private Label lbName;
        private Panel panel2;
        private Label lbAge;
        private Panel panel3;
        private Label lbBirth;
        private Panel panel4;
        private Label lbDept;
        private Panel panel5;
        private Label label6;
        private PictureBox pictureBox3;
        private ListBox listBox1;
        private Label label3;
        private TextBox textBox1;
        private Button btnResearch;
        private Button btnIssuance;
        private Label label1;
        private Label lbFee;
        private Panel panel6;
        private Label lbDate;
    }
}