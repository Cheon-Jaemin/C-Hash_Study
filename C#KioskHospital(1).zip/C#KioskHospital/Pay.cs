﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_KioskHospital
{
    public partial class Pay : Base
    {

        private PatientInfo selectedPatient = null;
        private void TotalPriceSum()
        {
            string medPriceText = lbMedPrice.Text.Replace("원", "").Trim();
            int medPrice = int.TryParse(medPriceText, out int result) ? result : 0;
            int medCertCount = (int)numericMedCert.Value;
            int docNoteCount = (int)numericDocNote.Value;

            int medCertPrice = medCertCount * 3000;
            int docNotePrice = docNoteCount * 3000;

            int NoInsurancePrice = medPrice + medCertPrice + docNotePrice;

            int discount = 0;
            if (ckbInsurance.Checked)
            {
                discount = (int)(NoInsurancePrice * 0.1);
            }

            int InsurancePrice = NoInsurancePrice - discount;

            lbMedCertPrice.Text = medCertPrice.ToString() + "원";
            lbDocNotePrice.Text = docNotePrice.ToString() + "원";
            lbInsuDiscount.Text = discount > 0 ? $"-{discount}원" : "0원";
            tbTotalPrice.Text = InsurancePrice.ToString() + "원";

        }

        public Pay()
        {
            InitializeComponent();
        }

        private void btnResearch_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text.Trim();
            listBox1.Items.Clear();

            var match = Base.patients.Where(p => p.Name == name).ToList();
            if (match.Count == 0)
            {
                MessageBox.Show("검색 결과가 없습니다.");
                return;
            }

            foreach (var patient in match)
            {
                listBox1.Items.Add($"{patient.Name} | {patient.Age}세 | {patient.Birth.ToShortDateString()}");
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1)
            {
                return;
            }

            string select = listBox1.SelectedItem.ToString();
            string[] parts = select.Split("|");

            string name = parts[0].Trim();
            int age = int.Parse(parts[1].Replace("세", "").Trim());
            DateTime birth = DateTime.Parse(parts[2].Trim());

            selectedPatient = Base.patients.FirstOrDefault(p =>
            p.Name == name && p.Age == age && p.Birth.Date == birth.Date);

            if (selectedPatient == null)
            {
                MessageBox.Show("본인정보를 다시 확인해주세요.");
                return;
            }

            if (selectedPatient.ReserveDept != null)
            {
                lbDept.Text = selectedPatient.ReserveDept.ToString();
                int medPrice = 10000;
                lbMedPrice.Text = $"{medPrice}원";
            }
            else
            {
                lbDept.Text = "해당 없음";
                int medPrice = 0;
                lbMedPrice.Text = $"{medPrice}원";
            }

            if (selectedPatient.MedCertIssuance)
            {
                lbMedCert.Text = "발급";
                numericMedCert.Enabled = true;
                numericMedCert.Value = 1;
            }
            else
            {
                lbMedCert.Text = "미발급";
                numericMedCert.Enabled = false;
                numericMedCert.Value = 0;
            }

            if (selectedPatient.DocNoteIssuance)
            {
                lbDocNote.Text = "발급";
                numericDocNote.Enabled = true;
                numericDocNote.Value = 1;
            }
            else
            {
                lbDocNote.Text = "미발급";
                numericDocNote.Enabled = false;
                numericDocNote.Value = 0;
            }

            TotalPriceSum();
        }

        private void numericMedCert_ValueChanged(object sender, EventArgs e)
        {
            TotalPriceSum();
        }

        private void numericDocNote_ValueChanged(object sender, EventArgs e)
        {
            TotalPriceSum();
        }

        private void ckbInsurance_CheckedChanged(object sender, EventArgs e)
        {
            TotalPriceSum();
        }

        private void cbPayType_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();

            if (cbPayType.SelectedItem == null)
            {
                return;
            }

            string select = cbPayType.SelectedItem.ToString();
            if (select == "신용카드")
            {
                listBox2.Items.Add("신한카드");
                listBox2.Items.Add("국민카드");
                listBox2.Items.Add("삼성카드");
                listBox2.Items.Add("현대카드");
                listBox2.Items.Add("우리카드");
            }
            else if (select == "체크카드")
            {
                listBox2.Items.Add("카카오뱅크");
                listBox2.Items.Add("토스뱅크");
                listBox2.Items.Add("신한뱅크");
                listBox2.Items.Add("국민뱅크");
                listBox2.Items.Add("농협은행");
            }
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            if(selectedPatient == null)
            {
                MessageBox.Show("환자 정보를 먼저 선택해주세요.");
                return;
            }

            if(int.Parse(tbTotalPrice.Text.Replace("원","")) == 0)
            {
                MessageBox.Show("결제할 항목이 없습니다.");
                return;
            }

            if(cbPayType.SelectedItem == null)
            {
                MessageBox.Show("결제 방식을 선택해주세요.");
                return;
            }

            if(listBox2.SelectedItem == null)
            {
                MessageBox.Show("은행을 선택해주세요.");
                return;
            }

            MessageBox.Show("결제가 완료되었습니다.\n 감사합니다.");

            this.Hide();
            StartMenu start = new StartMenu();
            start.Show();
        }
    }
}
