﻿namespace C_KioskHospital
{
    partial class ReserveChange
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            pictureBox1 = new PictureBox();
            listBox1 = new ListBox();
            label3 = new Label();
            textBox1 = new TextBox();
            btnResearch = new Button();
            lbFirstRes = new Label();
            btnChange = new Button();
            listBox2 = new ListBox();
            comboBox1 = new ComboBox();
            label6 = new Label();
            btnCancel = new Button();
            panel1 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("배스킨라빈스 B", 23.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(281, 192);
            label1.Name = "label1";
            label1.Size = new Size(139, 33);
            label1.TabIndex = 13;
            label1.Text = "변경/취소";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.v987_18a_Photoroom;
            pictureBox1.Location = new Point(297, 36);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 100);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(207, 270);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(298, 94);
            listBox1.TabIndex = 23;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(207, 243);
            label3.Name = "label3";
            label3.Size = new Size(35, 19);
            label3.TabIndex = 22;
            label3.Text = "이름";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(266, 241);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(157, 23);
            textBox1.TabIndex = 21;
            // 
            // btnResearch
            // 
            btnResearch.Font = new Font("Cafe24 Ohsquare", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnResearch.Location = new Point(438, 241);
            btnResearch.Name = "btnResearch";
            btnResearch.Size = new Size(67, 23);
            btnResearch.TabIndex = 20;
            btnResearch.Text = "검색";
            btnResearch.UseVisualStyleBackColor = true;
            btnResearch.Click += btnResearch_Click;
            // 
            // lbFirstRes
            // 
            lbFirstRes.Dock = DockStyle.Fill;
            lbFirstRes.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            lbFirstRes.Location = new Point(0, 0);
            lbFirstRes.Name = "lbFirstRes";
            lbFirstRes.Size = new Size(298, 34);
            lbFirstRes.TabIndex = 24;
            lbFirstRes.Text = "-";
            lbFirstRes.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnChange
            // 
            btnChange.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            btnChange.Location = new Point(508, 425);
            btnChange.Name = "btnChange";
            btnChange.Size = new Size(74, 45);
            btnChange.TabIndex = 28;
            btnChange.Text = "변경";
            btnChange.UseVisualStyleBackColor = true;
            btnChange.Click += btnChange_Click;
            // 
            // listBox2
            // 
            listBox2.Enabled = false;
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new Point(324, 425);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(148, 184);
            listBox2.TabIndex = 27;
            // 
            // comboBox1
            // 
            comboBox1.Enabled = false;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "내과", "이비인후과", "소아과" });
            comboBox1.Location = new Point(175, 425);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 26;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(111, 426);
            label6.Name = "label6";
            label6.Size = new Size(52, 19);
            label6.TabIndex = 25;
            label6.Text = "진료 과";
            // 
            // btnCancel
            // 
            btnCancel.Font = new Font("Cafe24 Ohsquare", 11.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            btnCancel.Location = new Point(508, 476);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(74, 45);
            btnCancel.TabIndex = 28;
            btnCancel.Text = "취소";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(lbFirstRes);
            panel1.Location = new Point(207, 370);
            panel1.Name = "panel1";
            panel1.Size = new Size(298, 34);
            panel1.TabIndex = 29;
            // 
            // ReserveChange
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(692, 791);
            Controls.Add(panel1);
            Controls.Add(btnCancel);
            Controls.Add(btnChange);
            Controls.Add(listBox2);
            Controls.Add(comboBox1);
            Controls.Add(label6);
            Controls.Add(listBox1);
            Controls.Add(label3);
            Controls.Add(textBox1);
            Controls.Add(btnResearch);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Name = "ReserveChange";
            Text = "Moble";
            Controls.SetChildIndex(pictureBox1, 0);
            Controls.SetChildIndex(label1, 0);
            Controls.SetChildIndex(btnResearch, 0);
            Controls.SetChildIndex(textBox1, 0);
            Controls.SetChildIndex(label3, 0);
            Controls.SetChildIndex(listBox1, 0);
            Controls.SetChildIndex(label6, 0);
            Controls.SetChildIndex(comboBox1, 0);
            Controls.SetChildIndex(listBox2, 0);
            Controls.SetChildIndex(btnChange, 0);
            Controls.SetChildIndex(btnCancel, 0);
            Controls.SetChildIndex(panel1, 0);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private ListBox listBox1;
        private Label label3;
        private TextBox textBox1;
        private Button btnResearch;
        private Label lbFirstRes;
        private Button btnChange;
        private ListBox listBox2;
        private ComboBox comboBox1;
        private Label label6;
        private Button btnCancel;
        private Panel panel1;
    }
}