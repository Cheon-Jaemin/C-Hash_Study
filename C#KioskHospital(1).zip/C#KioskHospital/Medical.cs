﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_KioskHospital
{
    public partial class Medical : Base
    {
        public Medical()
        {
            InitializeComponent();
        }



        private void btnFirstMed_Click(object sender, EventArgs e)
        {
            Navigation.FormStack.Push(this);
            FirstMed first = new FirstMed();
            first.Show();
            this.Hide();
        }

        private void btnReMed_Click(object sender, EventArgs e)
        {
            Navigation.FormStack.Push(this);
            ReMed reMed = new ReMed();
            reMed.Show();
            this.Hide();
        }
    }
}
