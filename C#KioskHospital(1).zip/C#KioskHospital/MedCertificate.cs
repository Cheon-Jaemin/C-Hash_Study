﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_KioskHospital
{
    public partial class MedCertificate : Base
    {
        private PatientInfo selectedPatient;

        public MedCertificate()
        {
            InitializeComponent();
            lbName.Text = "";
            lbDept.Text = "";
            lbAge.Text = "";
            lbBirth.Text = "";
            lbDate.Text = "";
        }

        private void btnResearch_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text.Trim();
            listBox1.Items.Clear();

            var match = Base.patients.Where(p => p.Name == name).ToList();
            if (match.Count == 0)
            {
                MessageBox.Show("검색 결과가 없습니다.");
                return;
            }

            foreach (var patient in match)
            {
                listBox1.Items.Add($"{patient.Name} | {patient.Age}세 | {patient.Birth.ToShortDateString()}");
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox1.SelectedIndex == -1)
            {
                return;
            }

            string select = listBox1.SelectedItem.ToString();
            string[] parts = select.Split("|");

            string name = parts[0].Trim();
            int age = int.Parse(parts[1].Replace("세", "").Trim());
            DateTime birth = DateTime.Parse(parts[2].Trim());

            lbAge.Text = age.ToString();
            lbName.Text = name;
            lbBirth.Text = birth.ToString("yyyy년 MM월 dd일");
            lbDate.Text = DateTime.Now.ToShortDateString();

            selectedPatient = Base.patients.FirstOrDefault(p =>
                p.Name == name &&
                p.Age == age &&
                p.Birth.Date == birth.Date);

            if (selectedPatient != null)
            {
                lbDept.Text = selectedPatient.ReserveDept;
            }
            else
            {
                lbDept.Text = "정보 없음";
            }

        }

        private void btnIssuance_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            {
                MessageBox.Show("본인정보를 확인하고 진행해주세요.");
                return;
            }

            selectedPatient.MedCertIssuance = true;
            MessageBox.Show("수납 시 요금이 부가됩니다.");
        }
    }
}
