﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_KioskHospital
{
    public class PatientInfo
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public DateTime Birth { get; set; }

        public string ReserveDept { get; set; }
        public string ReserveTime { get; set; }

        public bool MedCertIssuance { get; set; }
        public bool DocNoteIssuance { get; set; }
    }
}
