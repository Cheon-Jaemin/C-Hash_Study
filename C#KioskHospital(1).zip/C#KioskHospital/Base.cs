﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace C_KioskHospital
{
    public partial class Base : Form
    {
        List<Image> bannerImages = new List<Image>();
        private int Index = 0;

        public static Dictionary<string, List<string>> ReservedTimes = new Dictionary<string, List<string>>();
        public static List<PatientInfo> patients = new List<PatientInfo>();

        public static class Navigation
        {
            public static Stack<Form> FormStack = new Stack<Form>();
        }

        public static void SaveImg(Control TargetControl)
        {
            Rectangle Rect = TargetControl.RectangleToScreen(TargetControl.ClientRectangle);

            Bitmap bmp = new Bitmap(Rect.Width, Rect.Height);

            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.CopyFromScreen(Rect.Location, Point.Empty, Rect.Size);
            }

            using (SaveFileDialog saveDialog = new SaveFileDialog())
            {
                saveDialog.Filter = "PNG 파일 (*.png)|*.png";
                saveDialog.FileName = "증명서.png";

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    bmp.Save(saveDialog.FileName, System.Drawing.Imaging.ImageFormat.Png);
                    MessageBox.Show("출력이 완료되었습니다.");
                }
            }

        }

        public Base()
        {
            InitializeComponent();
           
            label2.Text = DateTime.Now.ToString("tt hh:mm");
            timer1.Start();
            timer1.Interval = 1000;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label2.Text = DateTime.Now.ToString("tt hh:mm");
        }

        private void btnPrevi_Click(object sender, EventArgs e)
        {
            if (Navigation.FormStack.Count > 0)
            {
                Form previousForm = Navigation.FormStack.Pop();
                this.Hide();
                previousForm.Show();
            }

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            this.Hide();
            Navigation.FormStack.Clear();
            StartMenu start = new StartMenu();
            start.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Base_Load(object sender, EventArgs e)
        {
            timer2.Interval = 3000;

            string bannerFolder = Path.Combine(Application.StartupPath, "Banner");

            if(Directory.Exists(bannerFolder))
            {
                string[] files = Directory.GetFiles(bannerFolder, "*.png");

                foreach(string file in files)
                {
                    bannerImages.Add(Image.FromFile(file));
                }

                if(bannerImages.Count > 0)
                {
                    MainBanner.Image = bannerImages[0];
                    timer2.Start();
                }
            }
          
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if(bannerImages.Count == 0)
            {
                return;
            }

            Index = (Index + 1) % bannerImages.Count;

            MainBanner.Image = bannerImages[Index];
        }
    }
}
