﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_KioskHospital
{
    public partial class Base : Form
    {

        public static Dictionary<string, List<string>> ReservedTimes = new Dictionary<string, List<string>>();
        public static List<PatientInfo> patients = new List<PatientInfo>();

        public static class Navigation
        {
            public static Stack<Form> FormStack = new Stack<Form>();
        }

        public Base()
        {
            InitializeComponent();
            label2.Text = DateTime.Now.ToString("tt hh:mm");
            timer1.Start();
            timer1.Interval = 1000;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label2.Text = DateTime.Now.ToString("tt hh:mm");
        }

        private void btnPrevi_Click(object sender, EventArgs e)
        {
            if (Navigation.FormStack.Count > 0)
            {
                Form previousForm = Navigation.FormStack.Pop();
                this.Hide();
                previousForm.Show();
            }

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            this.Hide();
            Navigation.FormStack.Clear();
            StartMenu start = new StartMenu();
            start.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
